# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 22:21:34 2021

@author: Lucas Valentim
"""

from RocketCasing import Casing

Casing.cas()